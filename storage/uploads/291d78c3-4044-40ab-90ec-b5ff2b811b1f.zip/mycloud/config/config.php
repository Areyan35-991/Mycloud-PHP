<?php
declare(strict_types=1);

// ─── Prevent direct access ───────────────────────────────────────────────────
if (!defined('APP_ROOT')) {
    die('Direct access not permitted.');
}

// ─── Environment ─────────────────────────────────────────────────────────────
define('APP_NAME',    'MyCloud');
define('APP_VERSION', '1.0.0');
define('APP_ENV',     getenv('APP_ENV') ?: 'production'); // 'development' | 'production'
define('BASE_URL',    getenv('APP_URL') ?: 'http://localhost/mycloud/public');

// ─── Paths ────────────────────────────────────────────────────────────────────
define('STORAGE_PATH',  APP_ROOT . '/storage/uploads');
define('DB_PATH',       APP_ROOT . '/db/cloud.db');
define('LOG_PATH',      APP_ROOT . '/storage/logs');

// ─── Security ────────────────────────────────────────────────────────────────
define('SESSION_LIFETIME',      3600);       // seconds — 1 hour idle timeout
define('CSRF_TOKEN_LENGTH',     32);
define('MAX_LOGIN_ATTEMPTS',    5);          // lockout after N failures
define('LOGIN_LOCKOUT_SECONDS', 900);        // 15 minutes

// ─── Upload limits ───────────────────────────────────────────────────────────
define('MAX_UPLOAD_BYTES', 500 * 1024 * 1024); // 500 MB

// Allowlist of permitted MIME types and their canonical extensions
// This is the ONLY source of truth for what gets accepted
define('ALLOWED_TYPES', [
    // Images
    'image/jpeg'      => 'jpg',
    'image/png'       => 'png',
    'image/gif'       => 'gif',
    'image/webp'      => 'webp',
    'image/svg+xml'   => 'svg',
    // Video
    'video/mp4'       => 'mp4',
    'video/webm'      => 'webm',
    'video/ogg'       => 'ogv',
    // Audio
    'audio/mpeg'      => 'mp3',
    'audio/ogg'       => 'ogg',
    'audio/wav'       => 'wav',
    // Documents
    'application/pdf' => 'pdf',
    // Archives
    'application/zip'                                                  => 'zip',
    'application/x-tar'                                                => 'tar',
    'application/gzip'                                                 => 'gz',
    // Data
    'text/plain'      => 'txt',
    'text/csv'        => 'csv',
    'application/json'=> 'json',
]);

// ─── Owner credentials ───────────────────────────────────────────────────────
// Change these before first use.
// To generate a new hash, run: php -r "echo password_hash('yourpassword', PASSWORD_ARGON2ID);"
define('OWNER_USERNAME', 'admin');
define('OWNER_PASSWORD_HASH',
    '$argon2id$v=19$m=65536,t=4,p=1$CHANGE_THIS_PLACEHOLDER$CHANGE_THIS_PLACEHOLDER'
);
// ↑ Replace the placeholder above with your real hash before deploying.
